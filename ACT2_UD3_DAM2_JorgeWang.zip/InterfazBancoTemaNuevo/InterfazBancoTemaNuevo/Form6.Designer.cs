﻿namespace Interfaz2
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            label30 = new Label();
            label29 = new Label();
            label28 = new Label();
            label27 = new Label();
            label26 = new Label();
            label25 = new Label();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label5 = new Label();
            label4 = new Label();
            label1 = new Label();
            label3 = new Label();
            label2 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label31 = new Label();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(37, 54, 75);
            button1.ForeColor = Color.Gainsboro;
            button1.Location = new Point(754, 522);
            button1.Name = "button1";
            button1.Size = new Size(78, 27);
            button1.TabIndex = 0;
            button1.Text = "Salir";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel1.ColumnCount = 5;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.8895035F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80.1105F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 219F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 97F));
            tableLayoutPanel1.Controls.Add(label30, 4, 5);
            tableLayoutPanel1.Controls.Add(label29, 3, 5);
            tableLayoutPanel1.Controls.Add(label28, 2, 5);
            tableLayoutPanel1.Controls.Add(label27, 1, 5);
            tableLayoutPanel1.Controls.Add(label26, 4, 4);
            tableLayoutPanel1.Controls.Add(label25, 3, 4);
            tableLayoutPanel1.Controls.Add(label24, 2, 4);
            tableLayoutPanel1.Controls.Add(label23, 1, 4);
            tableLayoutPanel1.Controls.Add(label22, 4, 3);
            tableLayoutPanel1.Controls.Add(label21, 3, 3);
            tableLayoutPanel1.Controls.Add(label20, 2, 3);
            tableLayoutPanel1.Controls.Add(label19, 1, 3);
            tableLayoutPanel1.Controls.Add(label18, 4, 2);
            tableLayoutPanel1.Controls.Add(label17, 3, 2);
            tableLayoutPanel1.Controls.Add(label16, 2, 2);
            tableLayoutPanel1.Controls.Add(label15, 1, 2);
            tableLayoutPanel1.Controls.Add(label14, 4, 1);
            tableLayoutPanel1.Controls.Add(label13, 3, 1);
            tableLayoutPanel1.Controls.Add(label12, 2, 1);
            tableLayoutPanel1.Controls.Add(label11, 1, 1);
            tableLayoutPanel1.Controls.Add(label5, 4, 0);
            tableLayoutPanel1.Controls.Add(label4, 3, 0);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label3, 2, 0);
            tableLayoutPanel1.Controls.Add(label2, 1, 0);
            tableLayoutPanel1.Controls.Add(label6, 0, 1);
            tableLayoutPanel1.Controls.Add(label7, 0, 2);
            tableLayoutPanel1.Controls.Add(label8, 0, 3);
            tableLayoutPanel1.Controls.Add(label9, 0, 4);
            tableLayoutPanel1.Controls.Add(label10, 0, 5);
            tableLayoutPanel1.Location = new Point(96, 53);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 21;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 61.01695F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 38.98305F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(652, 460);
            tableLayoutPanel1.TabIndex = 1;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint_1;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(556, 123);
            label30.Name = "label30";
            label30.Size = new Size(65, 15);
            label30.TabIndex = 29;
            label30.Text = "20/01/1950";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(437, 123);
            label29.Name = "label29";
            label29.Size = new Size(61, 15);
            label29.TabIndex = 28;
            label29.Text = "762134123";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(217, 123);
            label28.Name = "label28";
            label28.Size = new Size(116, 15);
            label28.TabIndex = 27;
            label28.Text = "Pmotos@gmail.com";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(47, 123);
            label27.Name = "label27";
            label27.Size = new Size(108, 15);
            label27.TabIndex = 26;
            label27.Text = "Pablo Motos Wang";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label26.Location = new Point(556, 102);
            label26.Name = "label26";
            label26.Size = new Size(69, 15);
            label26.TabIndex = 25;
            label26.Text = "11/11/1966";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(437, 102);
            label25.Name = "label25";
            label25.Size = new Size(61, 15);
            label25.TabIndex = 24;
            label25.Text = "692231023";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(217, 102);
            label24.Name = "label24";
            label24.Size = new Size(99, 15);
            label24.TabIndex = 23;
            label24.Text = "Cr10@gmail.com";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(47, 102);
            label23.Name = "label23";
            label23.Size = new Size(124, 15);
            label23.TabIndex = 22;
            label23.Text = "Cristiano Messi Suarez";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(556, 81);
            label22.Name = "label22";
            label22.Size = new Size(65, 15);
            label22.TabIndex = 21;
            label22.Text = "05/12/1990";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(437, 81);
            label21.Name = "label21";
            label21.Size = new Size(61, 15);
            label21.TabIndex = 20;
            label21.Text = "605132342";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(217, 81);
            label20.Name = "label20";
            label20.Size = new Size(125, 15);
            label20.TabIndex = 19;
            label20.Text = "LeandroY@gmail.com";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(47, 81);
            label19.Name = "label19";
            label19.Size = new Size(138, 15);
            label19.TabIndex = 18;
            label19.Text = "Leandro Yeismil Abudabi";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(556, 60);
            label18.Name = "label18";
            label18.Size = new Size(65, 15);
            label18.TabIndex = 17;
            label18.Text = "20/09/1970";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(437, 60);
            label17.Name = "label17";
            label17.Size = new Size(61, 15);
            label17.TabIndex = 16;
            label17.Text = "602312342";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(217, 60);
            label16.Name = "label16";
            label16.Size = new Size(125, 15);
            label16.TabIndex = 15;
            label16.Text = "YvanMati@gmail.com";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(47, 60);
            label15.Name = "label15";
            label15.Size = new Size(117, 15);
            label15.TabIndex = 14;
            label15.Text = "Yvan Matias Palacios";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(556, 37);
            label14.Name = "label14";
            label14.Size = new Size(65, 15);
            label14.TabIndex = 13;
            label14.Text = "18/02/1998";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(437, 37);
            label13.Name = "label13";
            label13.Size = new Size(61, 15);
            label13.TabIndex = 12;
            label13.Text = "682213452";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(217, 37);
            label12.Name = "label12";
            label12.Size = new Size(118, 15);
            label12.TabIndex = 11;
            label12.Text = "ismaGui@gmail.com";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(47, 37);
            label11.Name = "label11";
            label11.Size = new Size(133, 15);
            label11.TabIndex = 10;
            label11.Text = "Ismael Guitierrez Blanco";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(556, 1);
            label5.Name = "label5";
            label5.Size = new Size(71, 30);
            label5.TabIndex = 4;
            label5.Text = "Fecha Nacimiento";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(437, 1);
            label4.Name = "label4";
            label4.Size = new Size(56, 15);
            label4.TabIndex = 3;
            label4.Text = "Teléfono";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(4, 1);
            label1.Name = "label1";
            label1.Size = new Size(20, 15);
            label1.TabIndex = 0;
            label1.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(217, 1);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 2;
            label3.Text = "Correo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(47, 1);
            label2.Name = "label2";
            label2.Size = new Size(115, 15);
            label2.TabIndex = 1;
            label2.Text = "Nombre y Apellidos";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(4, 37);
            label6.Name = "label6";
            label6.Size = new Size(19, 15);
            label6.TabIndex = 5;
            label6.Text = "01";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(4, 60);
            label7.Name = "label7";
            label7.Size = new Size(19, 15);
            label7.TabIndex = 6;
            label7.Text = "02";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(4, 81);
            label8.Name = "label8";
            label8.Size = new Size(19, 15);
            label8.TabIndex = 7;
            label8.Text = "03";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(4, 102);
            label9.Name = "label9";
            label9.Size = new Size(19, 15);
            label9.TabIndex = 8;
            label9.Text = "04";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(4, 123);
            label10.Name = "label10";
            label10.Size = new Size(19, 15);
            label10.TabIndex = 9;
            label10.Text = "05";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label31.Location = new Point(342, 13);
            label31.Name = "label31";
            label31.Size = new Size(176, 30);
            label31.TabIndex = 2;
            label31.Text = "Tabla Empleados";
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(844, 561);
            Controls.Add(label31);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(button1);
            Name = "Form6";
            Text = "Form6";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label12;
        private Label label11;
        private Label label5;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label30;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label31;
    }
}